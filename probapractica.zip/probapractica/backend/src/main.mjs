import express from "express"
import cors from "cors"

const app = express()
app.use(cors())
app.use(express.json())

let testCom = [
    {
        
        description: ""
        
    },
    
]

app.delete("/com", (peticion, respuesta)=>{
    testCom.delete
    //const position = testCom.findIndex( esteTestCom => esteTestCom.description === peticion.body.description )
    //testCom.splice(position,1,peticion.body)
    respuesta.status(200)
    respuesta.send("¡¡¡Funciono!!!")
})

app.post("/com/", (peticion, respuesta)=>{
    testCom.push(peticion.body)
    respuesta.status(200)
    respuesta.send("Ok")
})

app.get("/com/", (_, respuesta)=>{
    respuesta.status(200)
    respuesta.send(JSON.stringify(testCom))
})

app.listen( 8000,()=>{
    console.log("Express traballando...");
})
