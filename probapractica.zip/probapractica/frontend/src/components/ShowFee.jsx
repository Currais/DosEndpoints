function ShowFee({tariff}) {
    return (

        <div>
            <p>
        
        {
            tariff.map(
            tariff3=><div>{tariff3.description}</div>
            )
        }

</p>

        </div>
        
        
    );
}

export default ShowFee