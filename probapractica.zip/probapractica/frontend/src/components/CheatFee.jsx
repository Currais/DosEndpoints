import { useState } from "react"

function CheatFee({refreshFunctionFee}) {

    const [description, setDescription] = useState("")

    function inputHandler(ev){          // Hace referencia con el "onInput = {inputHandler}". Sirve para el añadido de texto y etc.
        setDescription(ev.target.value)
    }

    function handlerClick(){   // Envia la información del texto añadido al backend con el handlerClick de la linea 56.

        

        const feeObject = {
            
            description: description,
            
        }

        const JSONfee = JSON.stringify(feeObject)

        fetch(
            "http://localhost:8000/com/",
            {
                method: "POST",
                headers: { 'Content-Type': 'application/json' },
                body: JSONfee,
            }
        )
        .then(callbackAPIanswer)
        .catch(callbackErrorConnection)

    }

    function callbackAPIanswer(answer) {
        if (answer.ok) {
            setDescription("")
            refreshFunctionFee()
        } else {
            alert(`Error code ${answer.status}`)
        }
    }

    function callbackErrorConnection(error) {
        alert("Cloud error connection")
    }

    return (
        <>
        <label>
            Nueva tarea
            <input type="text" value={description} onInput={inputHandler}/>
            
        </label>
        <button  onClick={handlerClick}>Añadir</button>
        <button  onclick={handlerClick}>Actualizar</button>
        </>
    )

}

export default CheatFee