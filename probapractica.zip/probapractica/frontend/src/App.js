import "./index.css"
import { useEffect, useState } from "react";
import ShowFee from "./components/ShowFee";
import CheatFee from "./components/CheatFee";

function App() {

  const [tariff2, setTariff2] = useState([])

  useEffect(
    obtainRefreshFees,
    
  )

  function obtainRefreshFees(){
    fetch("http://localhost:8000/com/").then(callbackAnswer)
  }

  function callbackAnswer(answer){
    answer.json().then(callbackNewData)
  }

  function callbackNewData(newData){
    setTariff2(newData)
  }

  return (
    <main>
      <h1>Test Project</h1>
      <CheatFee refreshFunctionFee={obtainRefreshFees}/>
      <ShowFee tariff={tariff2}/>
      
      
      
    </main>
    
    
  );

}

export default App;
